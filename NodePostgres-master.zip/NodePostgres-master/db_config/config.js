module.exports = {
  // host: "ec2-54-235-108-217.compute-1.amazonaws.com",
  // user: "ownumxfkwgkmyt",
  // password: "255a5621b9e45b37bb4f1b1ea0fb9ed163e3714a8147fa26c4dd4b30b1ea732f",
  // database: "ddgphpmj7ue7b4",
  host: "localhost",
  user: "postgres",
  password: "Sail8474",
  database: "thehj",
  port: 5432,
  secret: 'naksld1j5ais2hia8sdm5nakldn56aitiwgtiw7jjgjndsghaahbfjkabfafnfajfjjaa84siufd549dlk',
  salt:3  ,
  ssl:{ rejectUnauthorized: false }
};